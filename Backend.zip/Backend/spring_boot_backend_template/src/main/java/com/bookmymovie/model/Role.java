package com.bookmymovie.model;

public enum Role {

	 USER, ADMIN 
}
