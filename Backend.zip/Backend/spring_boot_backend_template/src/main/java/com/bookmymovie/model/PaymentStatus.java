package com.bookmymovie.model;

public enum PaymentStatus {

	 SUCCESS, FAILED, PENDING 
}
