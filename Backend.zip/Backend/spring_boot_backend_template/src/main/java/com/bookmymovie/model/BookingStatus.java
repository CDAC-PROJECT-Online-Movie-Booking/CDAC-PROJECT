package com.bookmymovie.model;

public enum BookingStatus {

	 CONFIRMED, CANCELLED, PENDING 
}
